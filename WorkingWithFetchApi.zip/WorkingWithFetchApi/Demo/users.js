async function getUsers() { 
    const res = await fetch("https://jsonplaceholder.typicode.com/users")
    const body = await res.json()
    return body
}

async function renderUsers() { 
    const users = await getUsers()
    const tbody = document.querySelector("tbody")
    for(let user of users) { 
        // Create tr
        const tr = document.createElement("tr")
        tr.innerHTML = `
            <td>${user.id}</td>
            <td>${user.username}</td>
            <td>${user.email}</td>
            <td>${user.address.city}</td>
            <td>${user.website}</td>
        `
        tbody.appendChild(tr)
    }
}

const btn = document.querySelector("button")
btn.addEventListener("click" , renderUsers)
// document.addEventListener("DOMContentLoaded" , renderUsers)