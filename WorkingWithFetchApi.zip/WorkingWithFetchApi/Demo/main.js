// Get Products
async function getProducts() {
    const res = await fetch("https://fakestoreapi.com/products")
    const data = await res.json()
    //console.log(data.slice(0 , 24))
    // console.log(data.length = 24)
    // return data.slice(0 , 24)
    return data
}

// Render Products
async function renderProducts() { 
    const products = await getProducts()
    const row = document.querySelector(".row")
   
    // Iterate Over Products
    for(let product of products) { 
        const div = document.createElement("div")
        div.className = "col-lg-4 col-md-6 col-sm-12 my-2"
        div.innerHTML = `
            <div class="card" style="width: 18rem;">
                <img src="${product.image}" 
                class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title">${product.title}</h5>
                    <p class="card-text">${product.description}</p>
                    <a href="https://fakestoreapi.com/" class="btn btn-dark mt-2">Go To Source</a>
                </div>
            </div>
        `
        row.appendChild(div)
    }
    
}

document.addEventListener("DOMContentLoaded" , renderProducts)

