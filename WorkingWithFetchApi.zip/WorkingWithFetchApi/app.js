// function getProducts() { 
//     fetch("https://fakestoreapi.com/products") reolve(res)
//     .then(res => res.json()) // res.json() return body from response // (body)
//     .then(body => console.log(body))
//     .catch(err => console.error(err))
// }

// getProducts()

async function getProducts() { 
    const response = await fetch("https://fakestoreapi.com/products")
    const body = await response.json()
    return body
}

getProducts()



function addNumbers(num1 , num2) { 
    return new Promise((resolve , reject) => { 
        if(typeof num1 == "number" &&
             typeof num2 == "number") { 
            resolve(num1 + num2)
        }else {
            reject("Please Enter Valid Numbers")
        }
    })
} 
// Eventual Completion or
addNumbers("10" , 2)
.then((result) => result + 5) // REsolve(17)
.then(result => result + 17) //resolve(34)
.then(result => result + 6) // resolve(40)
.then(result => console.log(result)) // 40
.catch(err => console.log(err))

//State (Fulfielled , Rejected)
// then(callback => return )